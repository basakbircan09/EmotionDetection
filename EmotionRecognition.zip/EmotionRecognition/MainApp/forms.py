from django import forms
from .models import UsrSession, ContactInfo

class UsrForm(forms.ModelForm):
    class Meta:
        model = UsrSession
        fields = ['input_image']

class ContactForm(forms.ModelForm):
    class Meta:
        model = ContactInfo
        fields = '__all__'