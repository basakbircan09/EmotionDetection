from django.contrib import admin
from .models import ContactInfo, UsrSession

admin.site.register(UsrSession)
admin.site.register(ContactInfo)