from django.shortcuts import render, redirect
from django import forms
from django.http import HttpResponseRedirect, HttpResponse
from django.urls import reverse
import os
from django.conf import settings
from pathlib import Path
from .forms import *
from .models import ContactInfo
import tensorflow as tf
import cv2
import numpy as np
from tensorflow.keras.models import load_model
from PIL import Image

MODEL_DIR = "MainApp/models/EmotionRecognitionModel.h5"

def haar(filepath):
    face_cascade = cv2.CascadeClassifier('MainApp/cascades/haarcascade_frontalface_default.xml')
    img = cv2.imread(filepath)
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    faces = face_cascade.detectMultiScale(gray, 1.3, 5)
    if faces == ():
        raise Exception('No Face')
    for (x,y,w,h) in faces:
        cv2.rectangle(img,(x,y),(x+w,y+h),(255,0,0),2)
        roi_gray = gray[y:y+h, x:x+w]
        roi_color = img[y:y+h, x:x+w]
        sub_face = img[y:y+h, x:x+w]
        sub_face_son=cv2.cvtColor(sub_face, cv2.COLOR_BGR2RGB)
    return sub_face_son

def emotion_detect(model_path, img_path):
    def prepare(filepath):
        IMG_SIZE = 128  
        img_array = cv2.imread(filepath, cv2.IMREAD_GRAYSCALE)
        new_array = cv2.resize(img_array, (IMG_SIZE, IMG_SIZE))  
        return new_array.reshape(-1, IMG_SIZE, IMG_SIZE, 1) 
    emotion_dict = {0: "Angry", 1: "Happy", 2: "Neutral", 3: "Sad", 4: "Surprised"}
    my_model=load_model(model_path)
    return emotion_dict[np.argmax(my_model.predict([prepare(img_path)]))]

def get_input(request):
    if UsrSession.objects.all():
        UsrSession.objects.all().delete()
    if request.method == 'POST':
        form = UsrForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            return HttpResponseRedirect('results')
    else:
        form = UsrForm()
    return render(request, 'MainApp/index.html',{'form': form})
    
def display_result(request):
    if request.method == 'GET':
        result_image = UsrSession.objects.get()
    try:
        INPUT_DIR = str(Path(str(settings.BASE_DIR) + result_image.input_image.url))
        cascaded_image_array = haar(INPUT_DIR)
        cascaded_image = Image.fromarray(cascaded_image_array)
        cascaded_image.save('media/images/cascaded.jpeg')
        INPUT_DIR = 'media/images/cascaded.jpeg'
        emotion = emotion_detect(MODEL_DIR, INPUT_DIR)
    except:
        return HttpResponseRedirect('invalid')
    return render(request, 'MainApp/results.html',{
        'result_image' : result_image,
        'emotion' : emotion
    })

def contact(request):
    invalid_flag = False
    success_flag = False
    if request.method == 'POST':
        form = ContactForm(request.POST)
        if form.is_valid():
            form.save()
            success_flag =True
        else:
            invalid_flag = True
        return render(request, "MainApp/contact.html", {
            'invalid_flag':invalid_flag, 
            'success_flag':success_flag,
            })
    else:
        form = ContactForm()
        return render(request, "MainApp/contact.html", {
            'form':form,
            'invalid_flag':invalid_flag, 
            'success_flag':success_flag,
            })

def about(request):
    return render(request, "MainApp/about.html")

def invalid(request):
    return render(request, "MainApp/invalid.html")

def database(request):
    return render(request, "MainApp/database.html")
