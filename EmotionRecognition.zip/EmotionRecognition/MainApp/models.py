from django.db import models
from django.contrib.auth.models import User

class UsrSession(models.Model):
    input_image = models.ImageField(upload_to = "images/", null = True, blank = True)

class ContactInfo(models.Model):
    name = models.CharField(max_length = 50)
    email = models.EmailField(max_length = 150)
    subject = models.CharField(max_length = 255)
    message = models.TextField()

    def __str__(self):
        return self.name