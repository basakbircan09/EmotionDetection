from django.urls import path
from . import views
from django.conf.urls.static import static
from django.conf import settings

app_name="MainApp"
urlpatterns= [
    path("", views.get_input, name="index"),
    path("results", views.display_result, name = "results"),
    path("contact", views.contact, name = "contact"),
    path("about", views.about, name = "about"),
    path("invalid", views.invalid, name = "invalid"),
    path("database", views.database, name = "database")
]

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root = settings.MEDIA_ROOT)



    